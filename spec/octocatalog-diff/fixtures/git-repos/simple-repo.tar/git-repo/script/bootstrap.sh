#!/usr/bin/env bash

cat >bootstrap_result.yaml <<-EOF
---
  env::pwd: ${PWD}
  env::home: ${HOME}
  env::path: ${PATH}
EOF
