#!/usr/bin/env bash

echo '---'
echo 'parameters:'
echo '  application: test'
exit 0
